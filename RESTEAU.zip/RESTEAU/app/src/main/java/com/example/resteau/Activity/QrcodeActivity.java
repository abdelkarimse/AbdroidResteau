package com.example.resteau.Activity;

import android.os.Bundle;
import android.widget.Button;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.resteau.R;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class QrcodeActivity extends AppCompatActivity {
    Button btn_scan;
    ActivityResultLauncher<ScanOptions> qrCodeLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode);
        btn_scan = findViewById(R.id.btn_scan);

        qrCodeLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (result != null && result.getContents() != null) {
                String scannedCode = result.getContents();
                new AlertDialog.Builder(this)
                        .setMessage("Scanned Code: " + scannedCode)
                        .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                        .show();
            }
        });

        btn_scan.setOnClickListener(v -> {
            ScanCode();
        });
    }

    private void ScanCode() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("Volume up to Flash on");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        qrCodeLauncher.launch(options);
    }
}
