package com.example.resteau.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.resteau.R;

public class ChoiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);

        Button radioGroup = findViewById(R.id.button_continue);
        RadioButton deliveryButton = findViewById(R.id.radio_delivery);
        RadioButton pickupButton = findViewById(R.id.radio_pickup);

        radioGroup.setOnClickListener((v) -> {
            if ( deliveryButton.isChecked()) {
                startActivity(new Intent(ChoiceActivity.this, DeliveryActivity.class));
            } else if ( pickupButton.isChecked()) {
                startActivity(new Intent(ChoiceActivity.this, QrcodeActivity.class));
            }
        });
    }
}
