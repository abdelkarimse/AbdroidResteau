package com.example.resteau.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.example.resteau.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView.Adapter adapterPlat;
    private RecyclerView recyclerViewPlat;
    private FloatingActionButton cart;
    private LinearLayout home, out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewPlat = findViewById(R.id.recyclerViewPlat);

        cart = findViewById(R.id.toCart);
        home = findViewById(R.id.Home);
        out = findViewById(R.id.out);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CartListActivity.class);
                startActivity(intent);

            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });

        String url = "http://172.18.208.1/api/api.php?get_fast_food_data";
        AndroidNetworking.get(url)
                .setPriority(Priority.LOW)
                .build()
                .getAsJSONArray(new JSONArrayRequestListener() {
                    @Override
                    public void onResponse(JSONArray response) {
                        ArrayList<FoodDomainse> platList = parsePlatData(response);
                    }

                    @Override
                    public void onError(ANError error) {
                    }
                });
    }

    private ArrayList<FoodDomainse> parsePlatData(JSONArray response) {
        ArrayList<FoodDomainse> platList = new ArrayList<>();

        try {
            for (int i = 0; i < response.length(); i++) {
                JSONObject platObject = response.getJSONObject(i);
                String platName = platObject.getString("name");
                double platPrice = platObject.getDouble("price");
                String platPic = platObject.getString("pic");
                int platId = platObject.getInt("id");
                String platCategory = platObject.getString("category");
                String platDescription = platObject.getString("description");
                FoodDomainse plat = new FoodDomainse(platName, platPrice, platPic, platId, platCategory, platDescription);
                platList.add(plat);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return platList;
    }
}
