package com.example.resteau.Activity;

public interface ChangeNumberItemsListtenar {
    void onChange();
}
